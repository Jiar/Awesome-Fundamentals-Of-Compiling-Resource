package Absyn;
import Symbol.Symbol;
abstract public class Dec extends Absyn {}
