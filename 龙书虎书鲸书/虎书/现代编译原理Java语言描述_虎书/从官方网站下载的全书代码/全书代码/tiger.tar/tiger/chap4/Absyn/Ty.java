package Absyn;
import Symbol.Symbol;
abstract public class Ty extends Absyn {}
