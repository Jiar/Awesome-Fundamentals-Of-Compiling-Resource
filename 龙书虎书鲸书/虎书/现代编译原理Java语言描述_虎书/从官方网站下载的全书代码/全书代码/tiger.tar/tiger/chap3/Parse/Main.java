package Parse;

public class Main {

  public static void main(String argv[])  {
      String filename = argv[0];
      new Parse(filename);
  }

}


