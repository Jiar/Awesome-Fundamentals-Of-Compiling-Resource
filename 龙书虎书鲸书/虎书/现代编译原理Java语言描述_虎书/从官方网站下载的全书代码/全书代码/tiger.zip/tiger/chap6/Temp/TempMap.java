package Temp;

public interface TempMap {public String tempMap(Temp.Temp t);}

