package Absyn;
import Symbol.Symbol;
abstract public class Exp extends Absyn {
}
