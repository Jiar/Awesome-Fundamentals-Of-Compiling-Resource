package Absyn;
import Symbol.Symbol;
abstract public class Absyn {
  public int pos;
}
