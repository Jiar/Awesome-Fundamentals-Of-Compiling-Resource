package Absyn;
import Symbol.Symbol;
abstract public class Var extends Absyn {
}
